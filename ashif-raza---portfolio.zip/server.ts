import express from "express";
import path from "path";
import fs from "fs";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Load knowledge base
let knowledgeBase: any = null;
try {
  const kbPath = path.join(process.cwd(), "src", "data", "knowledgeBase.json");
  if (fs.existsSync(kbPath)) {
    knowledgeBase = JSON.parse(fs.readFileSync(kbPath, "utf-8"));
  }
} catch (e) {
  console.error("Error loading knowledge base:", e);
}

// Lazy-initialize Gemini SDK
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key || key === "MY_GEMINI_API_KEY") {
      console.warn("GEMINI_API_KEY not configured. Falling back to local knowledge base matching.");
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// API Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

app.post("/api/chat", async (req, res) => {
  const { message, history } = req.body;

  if (!message) {
    return res.status(400).json({ error: "Message is required" });
  }

  // 1. Try to use Gemini API if key is available
  const ai = getGeminiClient();
  if (ai) {
    try {
      const kbString = JSON.stringify(knowledgeBase, null, 2);
      const systemInstruction = `You are "RazaBot", an intelligent, creative, and highly professional AI Assistant representing Ashif Raza.
Your goal is to answer questions about Ashif Raza truthfully, enthusiastically, and professionally based strictly on the following knowledge base:

${kbString}

Instructions:
1. Always speak in the first person plural or third person (e.g. "Ashif is..." or "We built...") or as his personal AI agent. Be polite, engaging, and structured.
2. Highlight his core projects: Trip Dhara (smart travel analytics with published research paper), IoT Predictive Maintenance (motor fault detection with vibration analysis), StudyMate AI (personalized learning), and Resume Analyzer.
3. If asked for his contact details, share his WhatsApp, LinkedIn (linkedin.com/in/ashif-raza-2b735b2a3), phone (+91-9798400721), and email (ashifrazaekma999@gmail.com).
4. If a question is unrelated to Ashif's expertise or portfolio, politely pivot the conversation back to his work, skills, or achievements.
5. Use clean formatting, markdown bullets, and keep your responses relatively concise but complete. No emojis overload, maintain high professional standards.`;

      // Transform history to Gemini API format if provided
      const chatHistory = history ? history.map((h: any) => ({
        role: h.sender === "user" ? "user" : "model",
        parts: [{ text: h.text }]
      })) : [];

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [
          ...chatHistory,
          { role: "user", parts: [{ text: message }] }
        ],
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      const responseText = response.text || "I apologize, but I couldn't generate a response.";
      return res.json({ response: responseText });
    } catch (err: any) {
      console.error("Gemini API Error:", err);
      // Fallback to local rule engine if API errors
    }
  }

  // 2. Local fallback rule engine (extremely robust, matching keywords in FAQs)
  if (knowledgeBase && knowledgeBase.faqs) {
    const textLower = message.toLowerCase();
    
    // Check for specific matches
    let bestMatch = null;
    let maxMatches = 0;

    for (const faq of knowledgeBase.faqs) {
      const qKeywords = faq.question.toLowerCase().split(/\s+/);
      let matchCount = 0;
      for (const word of qKeywords) {
        if (word.length > 3 && textLower.includes(word)) {
          matchCount++;
        }
      }
      if (matchCount > maxMatches) {
        maxMatches = matchCount;
        bestMatch = faq.answer;
      }
    }

    if (maxMatches > 0 && bestMatch) {
      return res.json({
        response: bestMatch + "\n\n*(Responding in Offline Knowledge Base Mode - configure GEMINI_API_KEY for dynamic conversations)*"
      });
    }
  }

  // Generic fallback if all else fails
  return res.json({
    response: "Hi! I'm RazaBot. I'm currently running in offline Mode. Ashif Raza is an Artificial Intelligence & Data Science Engineer specialized in Python, Machine Learning, and Web Development. You can reach out to him at ashifrazaekma999@gmail.com or call +91-9798400721. How can I help you find more about his background?",
  });
});

// Setup Vite Dev Server / Serve static build in Production
async function bootstrap() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server successfully started on http://localhost:${PORT}`);
  });
}

bootstrap();
