export interface Project {
  id: string;
  title: string;
  subtitle: string;
  period: string;
  description: string;
  abstract: string;
  keySkills: string[];
  techUsed: string[];
  githubUrl?: string;
  liveUrl?: string;
  hasAbstract: boolean;
  hasPoster: boolean;
  hasPPT: boolean;
  hasPaper: boolean;
}

export interface DocumentItem {
  id: string;
  title: string;
  category: "academic" | "achievement" | "project" | "career";
  description: string;
  filePath?: string;
  fileName: string;
  isUploaded: boolean;
}

export interface CertificateItem {
  id: string;
  title: string;
  platform: string;
  period: string;
  skillsLearned: string[];
  description: string;
  isUploaded: boolean;
}

export interface TimelineItem {
  id: string;
  year: string;
  title: string;
  subtitle: string;
  category: "education" | "experience" | "project" | "achievement";
  description: string;
  skills?: string[];
}

export interface SkillGroup {
  category: string;
  skills: {
    name: string;
    level: number; // percentage
    icon: string;
  }[];
}

export interface AchievementItem {
  id: string;
  title: string;
  description: string;
  date: string;
  category: "hackathon" | "publication" | "academic";
  badge: string;
}

export interface BlogItem {
  id: string;
  title: string;
  excerpt: string;
  date: string;
  readTime: string;
  link: string;
}

export interface ServiceItem {
  title: string;
  description: string;
  icon: string;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "bot";
  text: string;
  timestamp: string;
}
