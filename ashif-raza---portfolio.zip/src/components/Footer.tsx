import { ChevronUp, Github, Linkedin, Mail, Cpu } from "lucide-react";

interface FooterProps {
  onScrollToSection: (id: string) => void;
}

export default function Footer({ onScrollToSection }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="py-12 border-t border-slate-900/60 bg-slate-950/80 relative z-10 backdrop-blur-md px-4">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        
        {/* Logo/Brand */}
        <button
          onClick={() => onScrollToSection("hero")}
          className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors cursor-none"
        >
          <Cpu className="text-cyan-400" size={16} />
          <span className="font-mono text-xs font-bold tracking-widest">ASHIF RAZA © {currentYear}</span>
        </button>

        {/* Social connections */}
        <div className="flex items-center gap-6">
          <a
            href="https://github.com/ashifrazaekma"
            target="_blank"
            rel="noreferrer"
            className="text-slate-500 hover:text-cyan-400 transition-colors"
            title="GitHub"
          >
            <Github size={16} />
          </a>
          <a
            href="https://www.linkedin.com/in/ashif-raza-2b735b2a3"
            target="_blank"
            rel="noreferrer"
            className="text-slate-500 hover:text-cyan-400 transition-colors"
            title="LinkedIn"
          >
            <Linkedin size={16} />
          </a>
          <a
            href="mailto:ashifrazaekma999@gmail.com"
            className="text-slate-500 hover:text-cyan-400 transition-colors"
            title="Email"
          >
            <Mail size={16} />
          </a>
        </div>

        {/* Back to top button */}
        <button
          onClick={() => onScrollToSection("hero")}
          className="px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-cyan-400 hover:border-cyan-500/20 transition-all font-mono text-[10px] tracking-widest uppercase flex items-center gap-1.5 cursor-none"
        >
          <span>Top</span>
          <ChevronUp size={12} />
        </button>
      </div>
    </footer>
  );
}
