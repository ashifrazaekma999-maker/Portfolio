import { motion } from "motion/react";
import { MessageSquare, Quote, User } from "lucide-react";

const testimonials = [
  {
    name: "Dr. Rajesh Kumar",
    role: "Department Head / B.Tech Mentor",
    inst: "Prestige Institute PIEMR",
    quote: "Ashif displays exceptional technical acumen and rapid system comprehension. His predictive motor maintenance framework demonstrates deep synergy between IoT telemetry parsing and machine learning pipeline mechanics.",
    badge: "Faculty Head Review"
  },
  {
    name: "Priyanshi Dwivedi",
    role: "SIH Team Co-Author & Partner",
    inst: "Trip Dhara Project Lead",
    quote: "Collaborating with Ashif on TRIPधारा was an incredible engineering loop. His expertise in integrating Google Maps APIs and structuring optimal Firebase backends for offline fallback was crucial to our academic publication.",
    badge: "Peer Endorsement"
  },
  {
    name: "External Academic Jury",
    role: "SIH 2025 Evaluation Panel",
    inst: "Smart India Hackathon",
    quote: "The Trip Dhara navigation assistant stands out for its high responsiveness and critical safety SOS integration. It represents a highly practical application of geospatial analytics to regional travel safety.",
    badge: "SIH Jury Feedback"
  }
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 relative px-4 max-w-7xl mx-auto border-t border-slate-900/60">
      <div className="space-y-16">
        {/* Header */}
        <div className="text-center space-y-4">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-mono text-xs text-cyan-400 tracking-widest uppercase"
          >
            08 . REVIEWERS & COLLABORATIONS
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-5xl font-sans font-bold tracking-tight text-white"
          >
            Endorsements
          </motion.h2>
          <div className="w-12 h-1 bg-cyan-500 mx-auto rounded" />
        </div>

        {/* Testimonials grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((test, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.5 }}
              className="p-6 rounded-2xl bg-slate-900/10 border border-slate-900 flex flex-col justify-between backdrop-blur-md relative overflow-hidden group"
            >
              <Quote className="absolute right-4 top-4 text-slate-800/40 w-12 h-12 pointer-events-none" />

              <div className="space-y-4 relative z-10">
                {/* Badge */}
                <span className="inline-flex px-2 py-0.5 rounded bg-cyan-950/40 border border-cyan-500/20 text-cyan-400 font-mono text-[9px] font-bold uppercase tracking-wider">
                  {test.badge}
                </span>

                {/* Quote */}
                <p className="text-xs md:text-sm text-slate-300 leading-relaxed italic">
                  "{test.quote}"
                </p>
              </div>

              {/* Author footer */}
              <div className="pt-6 border-t border-slate-900/80 mt-6 flex items-center gap-3 relative z-10">
                <span className="w-9 h-9 rounded-full bg-slate-950 border border-slate-900 flex items-center justify-center text-slate-500">
                  <User size={16} />
                </span>
                <div>
                  <h4 className="text-xs font-bold text-slate-200">{test.name}</h4>
                  <p className="text-[10px] text-slate-500 font-mono">
                    {test.role}, <span className="text-slate-400">{test.inst}</span>
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
