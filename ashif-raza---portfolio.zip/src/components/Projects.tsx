import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ExternalLink,
  Github,
  FileText,
  Presentation,
  FileSpreadsheet,
  BookOpen,
  ChevronRight,
  X,
  Sparkles,
  Layers,
  Calendar
} from "lucide-react";
import { Project } from "../types";

const projectsList: Project[] = [
  {
    id: "trip_dhara",
    title: "Trip Dhara",
    subtitle: "Web-Based Intelligent Travel Analytics & Assistance System",
    period: "Sep 2025 - Jan 2026",
    keySkills: ["HTML", "CSS", "Python", "Firebase", "Google Maps API"],
    techUsed: ["Python", "Flask/Django", "HTML5", "CSS3", "JavaScript", "Firebase Database", "Google Maps SDK", "NLTK"],
    description: "Developed an advanced travel assistance and analytics system supporting trip planning and real-time route tracking. Integrates a smart chatbot, multilingual translator, expense manager, and a custom SOS safety model.",
    abstract: "Traveling has become an essential part of daily life. However, travelers face issues like lack of travel info, safety concerns, and language barriers. TRIPधारा is developed to address these issues. It offers trip planning, route optimization using Google Maps API, multi-language translation, integrated chatbot guidance, and an SOS emergency mechanism. Built on a modular web architecture, it handles user requests with Firebase backend support for high responsiveness, scaling, and offline local caching.",
    githubUrl: "https://github.com/ashifrazaekma/trip-dhara",
    liveUrl: "https://tripdhara.live",
    hasAbstract: true,
    hasPoster: true,
    hasPPT: true,
    hasPaper: true
  },
  {
    id: "predictive_maintenance",
    title: "Predictive Maintenance System",
    subtitle: "Industrial Motor Fault Detection with IoT",
    period: "March 2026 - May 2026",
    keySkills: ["Python", "Machine Learning", "IoT Sensors", "Data Analysis", "Streamlit", "Dashboard"],
    techUsed: ["Python", "Embedded C", "Scikit-Learn", "NumPy", "Pandas", "Matplotlib", "Streamlit", "Arduino IDE", "MPU6050 Sensor", "Buzzer Alert"],
    description: "Designed and built an end-to-end industrial IoT system. Captures real-time motor vibrations via an MPU6050 sensor on a DC motor, analyzes multi-axis raw data with Machine Learning to predict mechanical faults, and outputs anomalies on a Streamlit dashboard.",
    abstract: "Traditional maintenance systems are reactive and inefficient, leading to unexpected breakdowns and high repair costs. This project presents an AI-based predictive maintenance system. An MPU6050 sensor captures multi-axis vibration data from a DC motor, processed using Arduino UNO and analyzed with Python Scikit-learn algorithms (Random Forest/SVM) to detect early faults and classify mechanical conditions. An interactive Streamlit dashboard displays live vibration waveforms, anomaly indices, and sends real-time alerts via buzzer or notifications, reducing industrial down-time and maintenance costs.",
    githubUrl: "https://github.com/ashifrazaekma/predictive-maintenance-iot",
    liveUrl: "https://predictive-maintenance.streamlit.app",
    hasAbstract: true,
    hasPoster: true,
    hasPPT: true,
    hasPaper: false
  },
  {
    id: "studymate_ai",
    title: "StudyMate AI",
    subtitle: "Universal Smart Learning Platform",
    period: "July 2025 - Feb 2026",
    keySkills: ["HTML", "CSS", "Python", "Firebase", "React Js"],
    techUsed: ["React.js", "Tailwind CSS", "Node.js", "Express", "Firebase Auth & Firestore", "Gemini API"],
    description: "An AI-powered smart learning ecosystem. Adapts to individual pacing, auto-converts notes into custom flashcards, hosts mock quizzes, provides concept explanations, and charts learning progress in high fidelity.",
    abstract: "StudyMate AI is an advanced educational ecosystem that adapts to individual student pacing and cognitive style. It leverages React Js on the frontend and Firebase on the backend to achieve secure user authentication and instant database synchronization. The system leverages generative AI models to convert raw textbook notes into interactive flashcards and quizzes, supporting custom learning paths with integrated progress charting.",
    githubUrl: "https://github.com/ashifrazaekma/studymate-ai",
    liveUrl: "https://studymate-ai.web.app",
    hasAbstract: true,
    hasPoster: false,
    hasPPT: true,
    hasPaper: false
  },
  {
    id: "resume_analyzer",
    title: "Resume Analyzer",
    subtitle: "AI-Based Resume Evaluation System",
    period: "Dec 2025 - April 2026",
    keySkills: ["Python", "NLP", "Pandas", "Streamlit"],
    techUsed: ["Python", "Streamlit", "PyPDF2", "NLTK", "Scikit-Learn", "TF-IDF Vectorizer"],
    description: "An AI-driven application designed to parse candidate resumes, extract key technical skills, perform semantic keyword matching against job descriptions, and calculate automated resume scores.",
    abstract: "Parsing resumes manually is highly time-consuming for HR personnel. This project details the development of an automated AI-powered Resume Analyzer using Natural Language Processing (NLP). Using PDF text extraction libraries and advanced text vectorization, the system analyzes resume structure, matches custom-defined job profiles, performs similarity scoring, and prints an interactive Streamlit analytics dashboard pointing out missing technical keywords, skill matches, and visual score metrics.",
    githubUrl: "https://github.com/ashifrazaekma/resume-analyzer-ai",
    liveUrl: "https://resume-analyzer.streamlit.app",
    hasAbstract: true,
    hasPoster: false,
    hasPPT: false,
    hasPaper: false
  }
];

export default function Projects() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [activeTab, setActiveTab] = useState<"overview" | "abstract" | "resources">("overview");

  // Mock download prompt helper
  const handleResourceClick = (projectName: string, resourceType: string, isAvailable: boolean) => {
    if (!isAvailable) {
      alert(`The ${resourceType} for ${projectName} is currently configured as a placeholder. You can upload the PDF in the Document Library or Admin Panel to activate real-time rendering!`);
    } else {
      alert(`Downloading/Opening ${resourceType} for ${projectName} (Simulated Sandbox Fetch)...`);
    }
  };

  return (
    <section id="projects" className="py-24 relative px-4 max-w-7xl mx-auto">
      <div className="space-y-16">
        {/* Header */}
        <div className="text-center space-y-4">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-mono text-xs text-cyan-400 tracking-widest uppercase"
          >
            03 . CORE PORTFOLIO
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-5xl font-sans font-bold tracking-tight text-white"
          >
            Featured Solutions
          </motion.h2>
          <div className="w-12 h-1 bg-cyan-500 mx-auto rounded" />
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projectsList.map((project, idx) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.6 }}
              whileHover={{ y: -8 }}
              className="group relative flex flex-col justify-between rounded-2xl bg-gradient-to-b from-slate-900/60 to-slate-950/60 border border-slate-900 hover:border-cyan-500/25 transition-all duration-300 shadow-xl overflow-hidden p-6 md:p-8"
            >
              {/* Card visual glowing element */}
              <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              <div className="space-y-4 relative z-10">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-cyan-400 flex items-center gap-1">
                    <Calendar size={12} />
                    {project.period}
                  </span>
                  <span className="text-slate-500 uppercase font-bold tracking-widest">
                    Project 0{idx + 1}
                  </span>
                </div>

                <h3 className="text-xl md:text-2xl font-bold text-white group-hover:text-cyan-400 transition-colors">
                  {project.title}
                </h3>
                <p className="text-xs text-slate-400 font-mono italic leading-relaxed">
                  {project.subtitle}
                </p>
                <p className="text-sm text-slate-400 leading-relaxed pt-2">
                  {project.description}
                </p>

                {/* Key Skills Tags */}
                <div className="flex flex-wrap gap-2 pt-2">
                  {project.keySkills.slice(0, 4).map((skill, sIdx) => (
                    <span
                      key={sIdx}
                      className="px-2.5 py-0.5 rounded text-[10px] font-mono bg-slate-950 border border-slate-900 text-slate-300"
                    >
                      {skill}
                    </span>
                  ))}
                  {project.keySkills.length > 4 && (
                    <span className="px-2.5 py-0.5 rounded text-[10px] font-mono bg-slate-950 border border-slate-900 text-slate-500">
                      +{project.keySkills.length - 4} more
                    </span>
                  )}
                </div>
              </div>

              {/* Expander Trigger */}
              <div className="pt-6 relative z-10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {project.githubUrl && (
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 rounded bg-slate-950/80 border border-slate-900 text-slate-400 hover:text-white transition-colors"
                      title="GitHub Repository"
                    >
                      <Github size={16} />
                    </a>
                  )}
                  {project.liveUrl && (
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 rounded bg-slate-950/80 border border-slate-900 text-slate-400 hover:text-cyan-400 transition-colors"
                      title="Live Demo"
                    >
                      <ExternalLink size={16} />
                    </a>
                  )}
                </div>

                <button
                  onClick={() => {
                    setSelectedProject(project);
                    setActiveTab("overview");
                  }}
                  className="flex items-center gap-1 text-xs font-mono font-bold text-cyan-400 group-hover:translate-x-1 transition-transform"
                >
                  READ DETAILS <ChevronRight size={14} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Future Projects Placeholder */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="border-2 border-dashed border-slate-900 rounded-2xl p-8 text-center max-w-2xl mx-auto backdrop-blur-sm"
        >
          <Sparkles className="mx-auto text-slate-700 mb-3 animate-pulse" size={24} />
          <h4 className="text-slate-300 font-bold text-sm uppercase tracking-wider">Future Project In Development</h4>
          <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
            Deep Learning sequence modeling system for predictive industrial telemetry, integrating edge processing filters and localized fault classifiers.
          </p>
        </motion.div>
      </div>

      {/* Expanded Modal */}
      <AnimatePresence>
        {selectedProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProject(null)}
              className="absolute inset-0 bg-slate-950/80 backdrop-blur-md"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="relative w-full max-w-4xl max-h-[85vh] bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col z-10"
            >
              {/* Header */}
              <div className="p-6 md:p-8 border-b border-slate-900 bg-slate-900/10 flex items-start justify-between">
                <div>
                  <span className="text-xs font-mono text-cyan-400 bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-500/20">
                    {selectedProject.period}
                  </span>
                  <h3 className="text-xl md:text-3xl font-bold text-white mt-2">
                    {selectedProject.title}
                  </h3>
                  <p className="text-xs md:text-sm text-slate-400 font-mono mt-1 italic">
                    {selectedProject.subtitle}
                  </p>
                </div>
                <button
                  onClick={() => setSelectedProject(null)}
                  className="p-2 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Navigation Tabs */}
              <div className="flex border-b border-slate-900 bg-slate-900/20 px-6">
                <button
                  onClick={() => setActiveTab("overview")}
                  className={`px-4 py-3 text-xs font-mono font-semibold border-b-2 transition-all ${
                    activeTab === "overview"
                      ? "border-cyan-400 text-cyan-400"
                      : "border-transparent text-slate-500 hover:text-slate-300"
                  }`}
                >
                  Overview & Tech
                </button>
                <button
                  onClick={() => setActiveTab("abstract")}
                  className={`px-4 py-3 text-xs font-mono font-semibold border-b-2 transition-all ${
                    activeTab === "abstract"
                      ? "border-cyan-400 text-cyan-400"
                      : "border-transparent text-slate-500 hover:text-slate-300"
                  }`}
                >
                  Abstract Verbatim
                </button>
                <button
                  onClick={() => setActiveTab("resources")}
                  className={`px-4 py-3 text-xs font-mono font-semibold border-b-2 transition-all ${
                    activeTab === "resources"
                      ? "border-cyan-400 text-cyan-400"
                      : "border-transparent text-slate-500 hover:text-slate-300"
                  }`}
                >
                  Deliverables & Media
                </button>
              </div>

              {/* Content Box */}
              <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6">
                {activeTab === "overview" && (
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <h4 className="text-xs font-mono text-slate-500 uppercase tracking-widest flex items-center gap-1">
                        <Layers size={12} className="text-cyan-400" /> SUMMARY
                      </h4>
                      <p className="text-sm md:text-base text-slate-300 leading-relaxed">
                        {selectedProject.description}
                      </p>
                    </div>

                    <div className="space-y-3">
                      <h4 className="text-xs font-mono text-slate-500 uppercase tracking-widest">
                        Core Technologies Used
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedProject.techUsed.map((tech, idx) => (
                          <span
                            key={idx}
                            className="px-3 py-1 rounded bg-slate-900 border border-slate-800 text-xs font-mono text-cyan-300"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 pt-4 border-t border-slate-900">
                      {selectedProject.githubUrl && (
                        <a
                          href={selectedProject.githubUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-white flex items-center gap-2 hover:bg-slate-850 transition-all"
                        >
                          <Github size={14} />
                          GitHub Repo
                        </a>
                      )}
                      {selectedProject.liveUrl && (
                        <a
                          href={selectedProject.liveUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="px-4 py-2 rounded-lg bg-cyan-950/40 border border-cyan-500/30 text-xs font-mono text-cyan-400 flex items-center gap-2 hover:bg-cyan-950/60 transition-all"
                        >
                          <ExternalLink size={14} />
                          Live Demo Site
                        </a>
                      )}
                    </div>
                  </div>
                )}

                {activeTab === "abstract" && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 bg-cyan-950/20 px-3 py-2 rounded border border-cyan-500/10">
                      <FileText size={14} />
                      OFFICIAL RESEARCH / SYSTEM ARCHITECTURE MANUSCRIPT ABSTRACT
                    </div>
                    <p className="text-xs md:text-sm text-slate-400 leading-relaxed font-sans bg-slate-950 p-6 rounded-xl border border-slate-900 whitespace-pre-line">
                      {selectedProject.abstract}
                    </p>
                  </div>
                )}

                {activeTab === "resources" && (
                  <div className="space-y-6">
                    <p className="text-xs text-slate-500 font-mono">
                      Click components to simulate/trigger deliverables. Blue nodes represent available certified material placeholders.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Paper button */}
                      <button
                        onClick={() => handleResourceClick(selectedProject.title, "Research Paper Abstract Document", selectedProject.hasPaper)}
                        className={`p-4 rounded-xl border text-left flex items-start gap-3 transition-all ${
                          selectedProject.hasPaper
                            ? "bg-cyan-950/10 border-cyan-500/20 hover:border-cyan-500/50 text-slate-200"
                            : "bg-slate-950/40 border-slate-900 text-slate-600 cursor-not-allowed"
                        }`}
                      >
                        <BookOpen size={20} className={selectedProject.hasPaper ? "text-cyan-400" : "text-slate-700"} />
                        <div>
                          <p className="text-xs font-bold font-mono">Research Publication</p>
                          <p className="text-[10px] text-slate-500 mt-1">
                            {selectedProject.hasPaper ? "Available in Journal PDF format" : "No publication assigned"}
                          </p>
                        </div>
                      </button>

                      {/* Poster Button */}
                      <button
                        onClick={() => handleResourceClick(selectedProject.title, "Exhibition Poster JPEG", selectedProject.hasPoster)}
                        className={`p-4 rounded-xl border text-left flex items-start gap-3 transition-all ${
                          selectedProject.hasPoster
                            ? "bg-cyan-950/10 border-cyan-500/20 hover:border-cyan-500/50 text-slate-200"
                            : "bg-slate-950/40 border-slate-900 text-slate-600 cursor-not-allowed"
                        }`}
                      >
                        <FileText size={20} className={selectedProject.hasPoster ? "text-cyan-400" : "text-slate-700"} />
                        <div>
                          <p className="text-xs font-bold font-mono">Exhibition Poster</p>
                          <p className="text-[10px] text-slate-500 mt-1">
                            {selectedProject.hasPoster ? "Available - Verified high-res poster" : "No poster assigned"}
                          </p>
                        </div>
                      </button>

                      {/* Presentation Button */}
                      <button
                        onClick={() => handleResourceClick(selectedProject.title, "Presentation PPT Slides", selectedProject.hasPPT)}
                        className={`p-4 rounded-xl border text-left flex items-start gap-3 transition-all ${
                          selectedProject.hasPPT
                            ? "bg-cyan-950/10 border-cyan-500/20 hover:border-cyan-500/50 text-slate-200"
                            : "bg-slate-950/40 border-slate-900 text-slate-600 cursor-not-allowed"
                        }`}
                      >
                        <Presentation size={20} className={selectedProject.hasPPT ? "text-cyan-400" : "text-slate-700"} />
                        <div>
                          <p className="text-xs font-bold font-mono">Project PPT slides</p>
                          <p className="text-[10px] text-slate-500 mt-1">
                            {selectedProject.hasPPT ? "Available in PPTX layout" : "No presentation assigned"}
                          </p>
                        </div>
                      </button>

                      {/* Project PDF abstract Button */}
                      <button
                        onClick={() => handleResourceClick(selectedProject.title, "Full Project Abstract Report", selectedProject.hasAbstract)}
                        className={`p-4 rounded-xl border text-left flex items-start gap-3 transition-all ${
                          selectedProject.hasAbstract
                            ? "bg-cyan-950/10 border-cyan-500/20 hover:border-cyan-500/50 text-slate-200"
                            : "bg-slate-950/40 border-slate-900 text-slate-600 cursor-not-allowed"
                        }`}
                      >
                        <FileSpreadsheet size={20} className={selectedProject.hasAbstract ? "text-cyan-400" : "text-slate-700"} />
                        <div>
                          <p className="text-xs font-bold font-mono">Abstract Report PDF</p>
                          <p className="text-[10px] text-slate-500 mt-1">
                            {selectedProject.hasAbstract ? "Available - PDF document layout" : "No PDF abstract assigned"}
                          </p>
                        </div>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
