import { motion } from "motion/react";
import { Milestone, GraduationCap, Code2, Award, Calendar, ChevronDown, CheckCircle } from "lucide-react";
import { TimelineItem } from "../types";

const timelineItems: TimelineItem[] = [
  {
    id: "t_goal",
    year: "2027 & Beyond",
    title: "Future Aspirations",
    subtitle: "AI Lead & Physical Telemetry Engineer",
    category: "achievement",
    description: "Aiming to lead high-impact technical teams engineering industrial predictive controllers. Specialize in implementing real-time convolutional neural structures that analyze telemetry streams on the edge, saving massive operational and maintenance overhead.",
    skills: ["Edge AI", "Neural Control", "Scalable Pipelines", "Industrial Telemetry"]
  },
  {
    id: "t_pm",
    year: "March 2026 - May 2026",
    title: "Predictive Maintenance System",
    subtitle: "IoT Motor Fault Detection",
    category: "project",
    description: "Architected multi-axis vibration analytics loops for industrial DC motors using MPU6050 vibration sensors and Arduino. Engineered Scikit-Learn classifiers for fault forecasting and rendered high-res analytics inside a Streamlit dashboard.",
    skills: ["Embedded C", "Arduino IDE", "Scikit-Learn", "Vibration Analytics", "Streamlit"]
  },
  {
    id: "t_resume",
    year: "Dec 2025 - April 2026",
    title: "Resume Analyzer System",
    subtitle: "NLP-based Evaluation System",
    category: "project",
    description: "Designed a semantic resume matching engine. Parsed raw PDF CV layouts, matched keywords against customized job profiles using NLTK similarity and TF-IDF vectors, and printed results in an interactive scoring dashboard.",
    skills: ["Python", "NLP", "NLTK", "TF-IDF Vectorization", "PDF Parser"]
  },
  {
    id: "t_paper",
    year: "December 2025",
    title: "Research Paper Published",
    subtitle: "IJEASM Journal Vol. 6, Issue 12",
    category: "achievement",
    description: "Co-authored and published peer-reviewed research outlining the trip routing, Firebase caching structures, and SOS event loops of Trip Dhara system in the International Journal of Engineering Applied Science and Management.",
    skills: ["Research Methods", "Technical Writing", "Academic Publication", "System Architecture"]
  },
  {
    id: "t_trip",
    year: "Sep 2025 - Jan 2026",
    title: "Trip Dhara Assistant",
    subtitle: "Smart Travel Analytics & Safety",
    category: "project",
    description: "Developed a comprehensive travel assistance web app featuring route optimization via Google Maps SDK, multi-language translator modules, localized chat assistant, and fallback offline local caching.",
    skills: ["HTML5/CSS3", "JavaScript", "Firebase Auth", "Google Maps API", "NLTK API"]
  },
  {
    id: "t_sih",
    year: "September 2025",
    title: "Smart India Hackathon (SIH) 2025",
    subtitle: "College-Level Qualifier",
    category: "achievement",
    description: "Qualified for the college-level round representing PIEMR with the Trip Dhara project, displaying high-fidelity live tracking and integrated SOS emergencies.",
    skills: ["Rapid Prototyping", "Pitch Presentation", "UI/UX Architecture", "Route API Integrations"]
  },
  {
    id: "t_sm",
    year: "July 2025 - Feb 2026",
    title: "StudyMate AI Platform",
    subtitle: "Universal Personal Learning Platform",
    category: "project",
    description: "Built a customized adaptive education portal. Supported user authentication and Firestore syncing, generating quizzes and automated study schedules from raw textbook notes.",
    skills: ["React.js", "Node.js", "Express.js", "Firebase Firestore", "Generative AI API"]
  },
  {
    id: "t_btech",
    year: "2023 – 2027",
    title: "B.Tech in AI & Data Science",
    subtitle: "Prestige Institute (PIEMR), Bhopal",
    category: "education",
    description: "Enrolled in specialized B.Tech degree path under RGPV. In-depth focus on Machine Learning mathematics, database structures, Python workflows, statistical modeling, and data analytics. Maintained CGPA of 7.18/10.00.",
    skills: ["Data Structures", "Database Mechanics", "Machine Learning theory", "Statistical Mathematics"]
  },
  {
    id: "t_12th",
    year: "2021 – 2023",
    title: "Higher Secondary (12th Standard)",
    subtitle: "Rajendra College Chapra (Science)",
    category: "education",
    description: "Graduated with First Division in Science stream under BSEB, establishing robust logic, scientific reasoning, and mathematical principles.",
    skills: ["Advanced Calculus", "General Physics", "Inorganic Chemistry", "Analytical Reasoning"]
  }
];

export default function Timeline() {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case "education":
        return "border-blue-500 text-blue-400 bg-blue-950/30";
      case "project":
        return "border-cyan-500 text-cyan-400 bg-cyan-950/30";
      case "achievement":
        return "border-emerald-500 text-emerald-400 bg-emerald-950/30";
      default:
        return "border-slate-500 text-slate-400 bg-slate-950/30";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "education":
        return <GraduationCap size={16} />;
      case "project":
        return <Code2 size={16} />;
      case "achievement":
        return <Award size={16} />;
      default:
        return <Milestone size={16} />;
    }
  };

  return (
    <section id="timeline" className="py-24 relative px-4 max-w-7xl mx-auto">
      <div className="space-y-16">
        {/* Header */}
        <div className="text-center space-y-4">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-mono text-xs text-cyan-400 tracking-widest uppercase"
          >
            05 . CHRONOLOGICAL EVOLUTION
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-5xl font-sans font-bold tracking-tight text-white"
          >
            Journey & Milestones
          </motion.h2>
          <div className="w-12 h-1 bg-cyan-500 mx-auto rounded" />
        </div>

        {/* Timeline Path */}
        <div className="relative border-l border-slate-900 ml-4 md:ml-1/2 md:border-l-2 max-w-5xl mx-auto space-y-16 py-8">
          {timelineItems.map((item, idx) => {
            const isLeft = idx % 2 === 0;

            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: isLeft ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, ease: "easeOut" }}
                className={`relative pl-8 md:pl-0 md:w-1/2 ${
                  isLeft ? "md:pr-12 md:text-right md:ml-0" : "md:pl-12 md:ml-auto"
                }`}
              >
                {/* Timeline node */}
                <span className="absolute -left-3 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-slate-950 border-2 border-slate-850 shadow-[0_0_12px_rgba(6,182,212,0.1)] group-hover:border-cyan-400 transition-colors md:left-auto md:right-auto md:translate-x-0 md:-ml-3 md:left-0 md:right-0 mx-auto">
                  <span className="w-2 h-2 rounded-full bg-cyan-400" />
                </span>

                {/* Glass card container */}
                <div className="p-6 rounded-2xl bg-slate-900/10 border border-slate-900 hover:border-slate-800/80 transition-all backdrop-blur-md space-y-3 shadow-lg relative group">
                  {/* Subtle glowing halo */}
                  <div className="absolute inset-0 bg-radial-gradient(at_top_right,rgba(6,182,212,0.02)_0%,transparent_70%) pointer-events-none rounded-2xl" />

                  <div className={`flex flex-col gap-1.5 ${isLeft ? "md:items-end" : "md:items-start"}`}>
                    {/* Badge */}
                    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[10px] font-mono tracking-wider font-bold ${getCategoryColor(item.category)}`}>
                      {getCategoryIcon(item.category)}
                      {item.category.toUpperCase()}
                    </span>

                    {/* Year / Period */}
                    <p className="text-xs font-mono text-cyan-400 flex items-center gap-1 font-bold pt-1">
                      <Calendar size={12} />
                      {item.year}
                    </p>

                    {/* Title */}
                    <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-xs font-mono text-slate-400 italic">
                      {item.subtitle}
                    </p>
                  </div>

                  {/* Description */}
                  <p className="text-xs md:text-sm text-slate-400 leading-relaxed pt-1">
                    {item.description}
                  </p>

                  {/* Acquired Skills tags */}
                  {item.skills && (
                    <div className={`flex flex-wrap gap-1.5 pt-3 ${isLeft ? "md:justify-end" : "md:justify-start"}`}>
                      {item.skills.map((skill, sIdx) => (
                        <span
                          key={sIdx}
                          className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-950 border border-slate-900 text-slate-300"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
