import { useEffect, useRef } from "react";

export default function ThreeBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const scrollYRef = useRef(0);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });

  useEffect(() => {
    const handleScroll = () => {
      scrollYRef.current = window.scrollY;
    };

    const handleMouseMove = (e: MouseEvent) => {
      // Normalize mouse to -1 to 1
      mouseRef.current.targetX = (e.clientX / window.innerWidth) * 2 - 1;
      mouseRef.current.targetY = (e.clientY / window.innerHeight) * 2 - 1;
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("mousemove", handleMouseMove, { passive: true });

    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    // 3D Objects Setup
    const FOV = 350; // Camera focal length
    
    // 1. Particle Nodes (Neural Network)
    const particleCount = Math.min(120, Math.floor(width / 12));
    const particles: {
      x: number;
      y: number;
      z: number;
      ox: number;
      oy: number;
      oz: number;
      size: number;
      color: string;
      speed: number;
    }[] = [];

    for (let i = 0; i < particleCount; i++) {
      // Spawn particles in a cylinder volume
      const angle = Math.random() * Math.PI * 2;
      const radius = 100 + Math.random() * 400;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      const y = (Math.random() - 0.5) * 800;

      particles.push({
        x,
        y,
        z,
        ox: x,
        oy: y,
        oz: z,
        size: Math.random() * 1.5 + 0.5,
        color: i % 4 === 0 ? "rgba(6, 182, 212, 0.8)" : "rgba(59, 130, 246, 0.6)", // Cyan or Blue
        speed: Math.random() * 0.002 + 0.001,
      });
    }

    // 2. Binary Streams (Floating Code Blocks)
    const binaryCount = 20;
    const binaries: {
      x: number;
      y: number;
      z: number;
      val: string;
      alpha: number;
      speed: number;
    }[] = [];
    for (let i = 0; i < binaryCount; i++) {
      binaries.push({
        x: (Math.random() - 0.5) * 600,
        y: (Math.random() - 0.5) * 600,
        z: Math.random() * 400 - 200,
        val: Math.random() > 0.5 ? "1" : "0",
        alpha: Math.random() * 0.5 + 0.2,
        speed: Math.random() * 0.5 + 0.2,
      });
    }

    // 3. 3D Wireframe Cubes (Data Cubes)
    const cubes: {
      x: number;
      y: number;
      z: number;
      size: number;
      rotX: number;
      rotY: number;
      rotZ: number;
      speedX: number;
      speedY: number;
    }[] = [
      { x: -200, y: -150, z: 100, size: 50, rotX: 0.1, rotY: 0.2, rotZ: 0, speedX: 0.005, speedY: 0.008 },
      { x: 250, y: 180, z: -100, size: 70, rotX: 0.2, rotY: 0.1, rotZ: 0, speedX: 0.003, speedY: 0.004 },
      { x: 300, y: -250, z: 50, size: 40, rotX: 0.3, rotY: 0.3, rotZ: 0, speedX: 0.007, speedY: 0.005 },
    ];

    // 4. Glowing Circuits Traces
    const tracesCount = 6;
    const traces: {
      points: { x: number; y: number; z: number }[];
      progress: number;
      speed: number;
    }[] = [];

    for (let i = 0; i < tracesCount; i++) {
      const px = (Math.random() - 0.5) * 500;
      const py = (Math.random() - 0.5) * 500;
      const pz = (Math.random() - 0.5) * 200;
      traces.push({
        points: [
          { x: px, y: py, z: pz },
          { x: px + (Math.random() > 0.5 ? 100 : -100), y: py, z: pz },
          { x: px + 100, y: py + (Math.random() > 0.5 ? 100 : -100), z: pz },
        ],
        progress: Math.random(),
        speed: 0.003 + Math.random() * 0.002,
      });
    }

    // Animation Loop
    let angleY = 0;
    let angleX = 0;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Interpolate mouse coordinates for smooth lag
      const mouse = mouseRef.current;
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      // Scroll-driven camera alterations
      const scrollProgress = scrollYRef.current * 0.001;
      const camRotY = angleY + mouse.x * 0.15 + scrollProgress * 0.4;
      const camRotX = angleX + mouse.y * 0.15 + scrollProgress * 0.1;
      const camZShift = scrollYRef.current * 0.15; // Move closer as user scrolls

      // Natural rotation speed
      angleY += 0.001;
      angleX = Math.sin(angleY * 0.5) * 0.05;

      // Projection functions incorporating rotation matrixes
      const project = (x: number, y: number, z: number) => {
        // Rotate around Y-axis
        let x1 = x * Math.cos(camRotY) - z * Math.sin(camRotY);
        let z1 = x * Math.sin(camRotY) + z * Math.cos(camRotY);

        // Rotate around X-axis
        let y2 = y * Math.cos(camRotX) - z1 * Math.sin(camRotX);
        let z2 = y * Math.sin(camRotX) + z1 * Math.cos(camRotX);

        // Apply scroll-zoom modifier
        const finalZ = z2 + 200 + camZShift;

        // Projection
        const scale = FOV / Math.max(1, finalZ + FOV);
        const x2d = x1 * scale + width / 2;
        const y2d = y2 * scale + height / 2;

        return { x: x2d, y: y2d, scale, visible: finalZ > -FOV };
      };

      // --- Draw 3D Earth Dotted Globe in center-right ---
      const globeX = width > 768 ? 200 : 0;
      const globeY = 0;
      const globeZ = -50;
      const globeRadius = 150;
      const globePoints: { x: number; y: number; z: number }[] = [];
      const latCount = 12;
      const lonCount = 18;

      for (let i = 0; i < latCount; i++) {
        const lat = (Math.PI * i) / latCount;
        for (let j = 0; j < lonCount; j++) {
          const lon = (Math.PI * 2 * j) / lonCount;
          const x = globeX + globeRadius * Math.sin(lat) * Math.cos(lon + angleY * 0.8);
          const y = globeY + globeRadius * Math.cos(lat);
          const z = globeZ + globeRadius * Math.sin(lat) * Math.sin(lon + angleY * 0.8);
          globePoints.push({ x, y, z });
        }
      }

      // Render Globe
      ctx.fillStyle = "rgba(6, 182, 212, 0.25)";
      globePoints.forEach((p) => {
        const proj = project(p.x, p.y, p.z);
        if (proj.visible) {
          ctx.beginPath();
          ctx.arc(proj.x, proj.y, Math.max(0.5, proj.scale * 1.2), 0, Math.PI * 2);
          ctx.fill();
        }
      });

      // --- Draw Circuit traces ---
      ctx.strokeStyle = "rgba(14, 165, 233, 0.15)";
      ctx.lineWidth = 1;
      traces.forEach((t) => {
        ctx.beginPath();
        let first = true;
        t.points.forEach((pt) => {
          const proj = project(pt.x, pt.y, pt.z);
          if (proj.visible) {
            if (first) {
              ctx.moveTo(proj.x, proj.y);
              first = false;
            } else {
              ctx.lineTo(proj.x, proj.y);
            }
          }
        });
        ctx.stroke();

        // Glowing pulse on the circuit line
        t.progress += t.speed;
        if (t.progress > 1) t.progress = 0;

        // Interpolate along points
        const segmentCount = t.points.length - 1;
        const scaledProgress = t.progress * segmentCount;
        const currentSegmentIndex = Math.floor(scaledProgress);
        const segmentProgress = scaledProgress - currentSegmentIndex;

        if (currentSegmentIndex < segmentCount) {
          const pStart = t.points[currentSegmentIndex];
          const pEnd = t.points[currentSegmentIndex + 1];
          const pulsePt = {
            x: pStart.x + (pEnd.x - pStart.x) * segmentProgress,
            y: pStart.y + (pEnd.y - pStart.y) * segmentProgress,
            z: pStart.z + (pEnd.z - pStart.z) * segmentProgress,
          };

          const pulseProj = project(pulsePt.x, pulsePt.y, pulsePt.z);
          if (pulseProj.visible) {
            ctx.fillStyle = "#06b6d4";
            ctx.shadowBlur = 10;
            ctx.shadowColor = "#06b6d4";
            ctx.beginPath();
            ctx.arc(pulseProj.x, pulseProj.y, 3 * pulseProj.scale, 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0; // Reset
          }
        }
      });

      // --- Draw 3D Data Cubes ---
      cubes.forEach((c) => {
        c.rotX += c.speedX;
        c.rotY += c.speedY;

        const size = c.size;
        // 8 cube vertices relative to center
        const vertices = [
          { x: -size, y: -size, z: -size },
          { x: size, y: -size, z: -size },
          { x: size, y: size, z: -size },
          { x: -size, y: size, z: -size },
          { x: -size, y: -size, z: size },
          { x: size, y: -size, z: size },
          { x: size, y: size, z: size },
          { x: -size, y: size, z: size },
        ];

        // Rotate vertices of the cube locally
        const rotatedVertices = vertices.map((v) => {
          // Local Y rotation
          let x1 = v.x * Math.cos(c.rotY) - v.z * Math.sin(c.rotY);
          let z1 = v.x * Math.sin(c.rotY) + v.z * Math.cos(c.rotY);

          // Local X rotation
          let y2 = v.y * Math.cos(c.rotX) - z1 * Math.sin(c.rotX);
          let z2 = v.y * Math.sin(c.rotX) + z1 * Math.cos(c.rotX);

          // Position globally
          return { x: x1 + c.x, y: y2 + c.y, z: z2 + c.z };
        });

        const projectedVertices = rotatedVertices.map((v) => project(v.x, v.y, v.z));

        // Connect edges
        const edges = [
          [0, 1], [1, 2], [2, 3], [3, 0], // back face
          [4, 5], [5, 6], [6, 7], [7, 4], // front face
          [0, 4], [1, 5], [2, 6], [3, 7], // cross connections
        ];

        ctx.strokeStyle = "rgba(6, 182, 212, 0.4)";
        ctx.lineWidth = 1;
        edges.forEach(([u, v]) => {
          const pU = projectedVertices[u];
          const pV = projectedVertices[v];
          if (pU.visible && pV.visible) {
            ctx.beginPath();
            ctx.moveTo(pU.x, pU.y);
            ctx.lineTo(pV.x, pV.y);
            ctx.stroke();
          }
        });
      });

      // --- Draw 3D Neural Constellation Particles & Lines ---
      const projectedParticles = particles.map((p) => {
        // Slowly rotate around cylinder axis
        p.ox += Math.sin(angleY * 0.1 + p.speed) * 0.2;
        p.oy += Math.cos(angleY * 0.1 + p.speed) * 0.2;
        
        const proj = project(p.ox, p.oy, p.oz);
        return { ...p, ...proj };
      });

      // Draw Connection lines (neural network)
      ctx.lineWidth = 0.5;
      for (let i = 0; i < projectedParticles.length; i++) {
        const pi = projectedParticles[i];
        if (!pi.visible) continue;

        let connections = 0;
        for (let j = i + 1; j < projectedParticles.length; j++) {
          if (connections > 2) break; // Limit connectivity density

          const pj = projectedParticles[j];
          if (!pj.visible) continue;

          // Compute 3D distance
          const dx = pi.ox - pj.ox;
          const dy = pi.oy - pj.oy;
          const dz = pi.oz - pj.oz;
          const dist3d = Math.sqrt(dx * dx + dy * dy + dz * dz);

          if (dist3d < 160) {
            connections++;
            const alpha = (1 - dist3d / 160) * 0.25;
            ctx.strokeStyle = `rgba(59, 130, 246, ${alpha})`;
            ctx.beginPath();
            ctx.moveTo(pi.x, pi.y);
            ctx.lineTo(pj.x, pj.y);
            ctx.stroke();
          }
        }
      }

      // Render Particles
      projectedParticles.forEach((p) => {
        if (p.visible) {
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * p.scale * 1.5, 0, Math.PI * 2);
          ctx.fill();

          // Subdued particle glow
          if (p.size > 1.2) {
            ctx.fillStyle = "rgba(6, 182, 212, 0.15)";
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size * p.scale * 4, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      });

      // --- Draw Floating Binary streams ---
      ctx.font = "bold 10px monospace";
      binaries.forEach((b) => {
        b.y += b.speed;
        if (b.y > 400) b.y = -400; // recycle

        const proj = project(b.x, b.y, b.z);
        if (proj.visible) {
          ctx.fillStyle = `rgba(6, 182, 212, ${b.alpha * proj.scale})`;
          ctx.fillText(b.val, proj.x, proj.y);
        }
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none -z-10 bg-slate-950 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(10,25,47,0.8),rgba(2,6,23,1))]"
      style={{ mixBlendMode: "screen" }}
    />
  );
}
