import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  FileText,
  Upload,
  Download,
  Share2,
  Eye,
  CheckCircle,
  FileSpreadsheet,
  BookOpen,
  Mail,
  Award,
  Trash2,
  ExternalLink,
  X
} from "lucide-react";
import { DocumentItem } from "../types";

export default function Documents() {
  const [documents, setDocuments] = useState<DocumentItem[]>([
    { id: "res_1", title: "Ashif Raza - B.Tech Resume", category: "academic", description: "Comprehensive curriculum vitae highlighting AI B.Tech education, certifications, and ML project timeline.", fileName: "ashif_raza_resume.pdf", isUploaded: false },
    { id: "pub_1", title: "Research Publication (Trip Dhara)", category: "project", description: "Verbatim peer-reviewed research paper abstract published in the IJEASM Journal (Dec 2025).", fileName: "trip_dhara_ijeasm_paper.pdf", isUploaded: false },
    { id: "cert_ibm", title: "Python for Data Science - IBM Certificate", category: "academic", description: "Platform certification validating core pandas, numpy, and scientific cleaning workflows.", fileName: "ibm_python_data_science.pdf", isUploaded: false },
    { id: "cert_deloitte", title: "Data Analytics - Deloitte Certificate", category: "academic", description: "Industry credential focusing on dashboard presentation and data anomaly insights.", fileName: "deloitte_data_analytics.pdf", isUploaded: false },
    { id: "cert_cisco", title: "Cyber Security - Cisco Certificate", category: "academic", description: "Network security foundations, secure authentication, and cryptographic principles.", fileName: "cisco_cyber_security.pdf", isUploaded: false },
    { id: "project_abs", title: "Predictive Maintenance Abstract", category: "project", description: "Technical abstract outlining multi-axis motor vibration sensors and Arduino classification loops.", fileName: "predictive_maintenance_abstract.pdf", isUploaded: false },
    { id: "project_ppt", title: "Trip Dhara - Presentation PPT", category: "project", description: "Full presentation slides highlighting trip routing and SOS safety models.", fileName: "trip_dhara_slides.ppt", isUploaded: false },
    { id: "project_poster", title: "Predictive Maintenance - Poster Design", category: "project", description: "Exhibition presentation board visualizing model accuracy benchmarks and DC motor setups.", fileName: "predictive_maintenance_poster.jpg", isUploaded: false },
    { id: "intern_cert", title: "Internship Certificate Placeholder", category: "career", description: "Placeholder for upcoming ML Engineering internship certifications.", fileName: "internship_certificate.pdf", isUploaded: false },
    { id: "hack_cert", title: "Hackathon GDG Certificate", category: "achievement", description: "Credential validating participation in GDG x PIEMR hackathon loops.", fileName: "gdg_hackathon_certificate.pdf", isUploaded: false },
    { id: "offer_letter", title: "Offer Letter Placeholder", category: "career", description: "Placeholder for upcoming AI Engineering and analyst offer letters.", fileName: "offer_letter.pdf", isUploaded: false },
    { id: "recom_letter", title: "Recommendation Letter Placeholder", category: "academic", description: "Academic reference letters endorsed by Prestige Institute department mentors.", fileName: "recommendation_letter.pdf", isUploaded: false }
  ]);

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [viewingDoc, setViewingDoc] = useState<DocumentItem | null>(null);

  // Trigger brief alert feedback
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Handle simulated file uploads
  const handleFileUpload = (id: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      setDocuments((prev) =>
        prev.map((doc) =>
          doc.id === id
            ? { ...doc, isUploaded: true, fileName: file.name, description: `User uploaded: ${file.name} (${(file.size / 1024).toFixed(1)} KB)` }
            : doc
        )
      );
      triggerToast(`Successfully uploaded "${file.name}" into sandbox!`);
    }
  };

  // Remove uploaded item and revert to empty state
  const handleRemoveFile = (id: string) => {
    setDocuments((prev) =>
      prev.map((doc) =>
        doc.id === id ? { ...doc, isUploaded: false } : doc
      )
    );
    triggerToast("Document reverted to empty placeholder.");
  };

  // Simulated download loop
  const handleDownload = (doc: DocumentItem) => {
    if (!doc.isUploaded) {
      triggerToast(`Downloading empty template placeholder for "${doc.title}"...`);
    } else {
      triggerToast(`Downloading user-uploaded file: "${doc.fileName}"...`);
    }
  };

  // Share action (copies clipboard URL)
  const handleShare = (doc: DocumentItem) => {
    const mockUrl = `${window.location.origin}/documents/${doc.id}`;
    navigator.clipboard.writeText(mockUrl);
    triggerToast(`Copied document share link for "${doc.title}" to clipboard!`);
  };

  const getIcon = (category: string) => {
    switch (category) {
      case "academic":
        return <Award className="text-cyan-400" size={18} />;
      case "project":
        return <BookOpen className="text-cyan-400" size={18} />;
      case "career":
        return <Mail className="text-cyan-400" size={18} />;
      default:
        return <FileSpreadsheet className="text-cyan-400" size={18} />;
    }
  };

  return (
    <section id="documents" className="py-24 relative px-4 max-w-7xl mx-auto">
      <div className="space-y-16">
        {/* Header */}
        <div className="text-center space-y-4">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-mono text-xs text-cyan-400 tracking-widest uppercase"
          >
            04 . CREDENTIAL VAULT
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-5xl font-sans font-bold tracking-tight text-white"
          >
            Document Library
          </motion.h2>
          <div className="w-12 h-1 bg-cyan-500 mx-auto rounded" />
        </div>

        {/* Info notice about empty placeholders */}
        <div className="p-4 rounded-xl bg-cyan-950/20 border border-cyan-500/10 text-cyan-400 text-xs md:text-sm text-center max-w-3xl mx-auto backdrop-blur-sm">
          💡 <strong>Sandbox Administrator Ready:</strong> This library initializes with empty secure placeholders. Drop or select real files (PDF, PPT, PNG) onto any container to populate Ashif's digital archive instantly.
        </div>

        {/* Documents grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {documents.map((doc) => (
            <div
              key={doc.id}
              className={`p-6 rounded-xl border flex flex-col justify-between transition-all backdrop-blur-md relative overflow-hidden group ${
                doc.isUploaded
                  ? "bg-slate-900/30 border-cyan-500/20 shadow-[0_0_15px_rgba(6,182,212,0.05)]"
                  : "bg-slate-950/60 border-slate-900/80 hover:border-slate-800"
              }`}
            >
              <div className="space-y-4">
                {/* Top card metadata */}
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-xs font-mono font-medium text-slate-400">
                    {getIcon(doc.category)}
                    {doc.category.toUpperCase()}
                  </span>
                  {doc.isUploaded ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-mono text-cyan-400 bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-500/20">
                      <CheckCircle size={10} /> ACTIVE
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[10px] font-mono text-slate-500 bg-slate-950/60 px-2 py-0.5 rounded border border-slate-900">
                      EMPTY
                    </span>
                  )}
                </div>

                {/* Title */}
                <div>
                  <h3 className="text-base font-bold text-white group-hover:text-cyan-400 transition-colors">
                    {doc.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed h-12 overflow-hidden">
                    {doc.description}
                  </p>
                </div>
              </div>

              {/* Action buttons or upload container */}
              <div className="pt-6 border-t border-slate-900 mt-4 space-y-3">
                {doc.isUploaded ? (
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-[10px] font-mono text-slate-500 truncate max-w-[120px]">
                      {doc.fileName}
                    </p>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => setViewingDoc(doc)}
                        className="p-1.5 rounded bg-slate-950 hover:bg-slate-900 border border-slate-900 text-slate-400 hover:text-white transition-colors"
                        title="View Document"
                      >
                        <Eye size={14} />
                      </button>
                      <button
                        onClick={() => handleDownload(doc)}
                        className="p-1.5 rounded bg-slate-950 hover:bg-slate-900 border border-slate-900 text-slate-400 hover:text-white transition-colors"
                        title="Download Document"
                      >
                        <Download size={14} />
                      </button>
                      <button
                        onClick={() => handleShare(doc)}
                        className="p-1.5 rounded bg-slate-950 hover:bg-slate-900 border border-slate-900 text-slate-400 hover:text-white transition-colors"
                        title="Share Document"
                      >
                        <Share2 size={14} />
                      </button>
                      <button
                        onClick={() => handleRemoveFile(doc.id)}
                        className="p-1.5 rounded bg-red-950/20 hover:bg-red-900/30 border border-red-500/10 text-red-400 transition-colors"
                        title="Delete Document"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ) : (
                  <label className="flex items-center justify-center gap-2 py-3 px-4 rounded-lg border border-dashed border-slate-800 hover:border-cyan-500/40 hover:bg-cyan-500/[0.01] transition-all cursor-pointer text-xs font-mono text-slate-400">
                    <Upload size={14} className="text-slate-500" />
                    <span>Upload {doc.title.includes("Poster") ? "Poster" : "PDF"}</span>
                    <input
                      type="file"
                      accept=".pdf,.ppt,.pptx,.jpg,.jpeg,.png"
                      className="hidden"
                      onChange={(e) => handleFileUpload(doc.id, e)}
                    />
                  </label>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Floating global Toast notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 px-4 py-3 bg-slate-950 border border-cyan-500/30 rounded-xl text-cyan-300 text-xs font-mono shadow-[0_0_20px_rgba(6,182,212,0.15)] backdrop-blur-md flex items-center gap-2"
          >
            <CheckCircle size={14} className="text-cyan-400" />
            {toastMessage}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Viewing PDF Modal Overlay */}
      <AnimatePresence>
        {viewingDoc && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setViewingDoc(null)}
              className="absolute inset-0 bg-slate-950/85 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-2xl bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-2xl z-10 p-6 md:p-8 space-y-6"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest flex items-center gap-1">
                    {getIcon(viewingDoc.category)} {viewingDoc.category}
                  </span>
                  <h3 className="text-lg md:text-xl font-bold text-white mt-1">{viewingDoc.title}</h3>
                </div>
                <button
                  onClick={() => setViewingDoc(null)}
                  className="p-1.5 rounded bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Document Cover Preview Sheet */}
              <div className="aspect-[4/3] rounded-lg border border-slate-900 bg-slate-950 flex flex-col items-center justify-center text-center p-8 space-y-4 select-none relative overflow-hidden">
                <div className="absolute inset-0 bg-radial-gradient(at_center_center,rgba(6,182,212,0.05)_0%,transparent_70%) pointer-events-none" />
                
                <FileText size={48} className="text-cyan-400 animate-pulse" />
                <div className="space-y-1 relative z-10">
                  <p className="text-xs font-mono text-slate-500">DIGITAL ARCHIVE COVER SHEET</p>
                  <p className="text-sm font-bold text-slate-200">{viewingDoc.fileName}</p>
                </div>
                <p className="text-xs text-slate-400 max-w-sm relative z-10 leading-relaxed">
                  {viewingDoc.description}
                </p>
                <div className="flex items-center gap-3 relative z-10 pt-2">
                  <button
                    onClick={() => handleDownload(viewingDoc)}
                    className="px-4 py-2 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-xs font-bold flex items-center gap-2 transition-colors"
                  >
                    <Download size={12} /> Download PDF
                  </button>
                  <button
                    onClick={() => handleShare(viewingDoc)}
                    className="px-4 py-2 rounded bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 font-mono text-xs flex items-center gap-2 transition-colors"
                  >
                    <Share2 size={12} /> Share Link
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
