import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MessageSquare, X, Send, Bot, User, Check, AlertCircle } from "lucide-react";
import { ChatMessage } from "../types";

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      sender: "bot",
      text: "Hi there! I'm RazaBot, Ashif Raza's personal AI agent. Ask me anything about his ML models, B.Tech career at PIEMR, published papers, or custom full-stack solutions!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const suggestions = [
    "Who is Ashif Raza?",
    "Show his key projects",
    "What are his certifications?",
    "Show research papers",
    "How to contact Ashif?"
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen, isTyping]);

  const handleSendMessage = async (text: string) => {
    if (!text.trim()) return;

    const userMessage: ChatMessage = {
      id: `u_${Date.now()}`,
      sender: "user",
      text: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);

    try {
      // Build history payload for server-side Gemini conversational coherence
      const historyPayload = messages.slice(-10).map((m) => ({
        sender: m.sender,
        text: m.text
      }));

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, history: historyPayload })
      });

      const data = await res.json();
      
      setIsTyping(false);
      
      const botMessage: ChatMessage = {
        id: `b_${Date.now()}`,
        sender: "bot",
        text: data.response || "I apologize, but I could not synthesize a response.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages((prev) => [...prev, botMessage]);
    } catch (err) {
      console.error("Chat API Error:", err);
      setIsTyping(false);
      
      // Local fallback answer just in case connection blocks
      const fallbackMessage: ChatMessage = {
        id: `b_${Date.now()}_err`,
        sender: "bot",
        text: "It seems I had trouble connecting to my brain servers. Ashif is an AI & Data Science B.Tech student with a CGPA of 7.18/10.00, skilled in Python, Machine Learning (Scikit-Learn), IoT (vibration analysis), and Web Development (Firebase, React). You can contact him at ashifrazaekma999@gmail.com or call +91-9798400721.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, fallbackMessage]);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      {/* Floating Trigger Button */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="w-14 h-14 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.4)] cursor-none"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <X size={22} />
            </motion.div>
          ) : (
            <motion.div
              key="chat"
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <MessageSquare size={22} />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            transition={{ type: "spring", damping: 22, stiffness: 220 }}
            className="w-[90vw] sm:w-[380px] h-[500px] rounded-2xl border border-slate-800 bg-slate-950/95 shadow-2xl overflow-hidden flex flex-col mb-4 backdrop-blur-md"
          >
            {/* Header */}
            <div className="p-4 border-b border-slate-900 bg-slate-900/40 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="w-8 h-8 rounded-full bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                  <Bot size={16} />
                </span>
                <div>
                  <h4 className="text-xs font-bold font-sans text-white">RazaBot AI</h4>
                  <p className="text-[9px] font-mono text-cyan-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
                    GEMINI ENGINE ONLINE
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition-all"
              >
                <X size={14} />
              </button>
            </div>

            {/* Suggestions loop */}
            <div className="px-3 py-2 border-b border-slate-900/60 bg-slate-950 flex gap-2 overflow-x-auto whitespace-nowrap scrollbar-none select-none">
              {suggestions.map((s, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(s)}
                  className="px-3 py-1 rounded-full bg-slate-900/60 border border-slate-850 hover:border-cyan-500/30 text-slate-300 font-mono text-[9px] font-semibold transition-all"
                >
                  {s}
                </button>
              ))}
            </div>

            {/* Messages box */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950/20">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex items-start gap-2.5 max-w-[85%] ${
                    m.sender === "user" ? "ml-auto flex-row-reverse" : ""
                  }`}
                >
                  <span
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] ${
                      m.sender === "user"
                        ? "bg-slate-900 border border-slate-800 text-slate-200"
                        : "bg-cyan-950/40 border border-cyan-500/20 text-cyan-400"
                    }`}
                  >
                    {m.sender === "user" ? <User size={12} /> : <Bot size={12} />}
                  </span>
                  <div
                    className={`p-3 rounded-xl border text-xs leading-relaxed whitespace-pre-wrap ${
                      m.sender === "user"
                        ? "bg-gradient-to-r from-cyan-600/10 to-blue-600/10 border-cyan-500/25 text-slate-100"
                        : "bg-slate-900/20 border-slate-900/80 text-slate-300"
                    }`}
                  >
                    {m.text}
                    <span className="block text-[8px] text-slate-500 mt-1 text-right font-mono">
                      {m.timestamp}
                    </span>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex items-start gap-2.5 max-w-[85%]">
                  <span className="w-6 h-6 rounded-full bg-cyan-950/40 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                    <Bot size={12} />
                  </span>
                  <div className="p-3 rounded-xl border bg-slate-900/20 border-slate-900/80 flex items-center gap-1 py-4">
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* Input Footer */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(inputValue);
              }}
              className="p-3 border-t border-slate-900 bg-slate-900/20 flex items-center gap-2"
            >
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Message RazaBot..."
                className="flex-1 px-3 py-2 text-xs text-white placeholder-slate-500 bg-slate-950 border border-slate-900 rounded-lg focus:outline-none focus:border-cyan-500/50 transition-colors font-sans"
              />
              <button
                type="submit"
                className="p-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:opacity-90 transition-opacity cursor-none"
              >
                <Send size={14} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
