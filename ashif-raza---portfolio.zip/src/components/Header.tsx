import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, ArrowUpRight, Cpu } from "lucide-react";

interface HeaderProps {
  onScrollToSection: (id: string) => void;
  activeSection: string;
}

export default function Header({ onScrollToSection, activeSection }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  const menuItems = [
    { label: "About", id: "about" },
    { label: "Skills", id: "skills" },
    { label: "Projects", id: "projects" },
    { label: "Documents", id: "documents" },
    { label: "Timeline", id: "timeline" },
    { label: "Contact", id: "contact" }
  ];

  useEffect(() => {
    const updateScroll = () => {
      const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (scrollHeight > 0) {
        setScrollProgress((window.scrollY / scrollHeight) * 100);
      }
    };
    window.addEventListener("scroll", updateScroll, { passive: true });
    return () => window.removeEventListener("scroll", updateScroll);
  }, []);

  return (
    <>
      {/* Top Scroll Progress bar */}
      <div className="fixed top-0 left-0 h-0.5 bg-gradient-to-r from-cyan-500 via-blue-500 to-cyan-400 z-50 transition-all duration-75" style={{ width: `${scrollProgress}%` }} />

      <header className="fixed top-0 left-0 right-0 z-40 bg-slate-950/40 border-b border-slate-900/60 backdrop-blur-md select-none">
        <div className="max-w-7xl mx-auto px-4 h-16 md:h-20 flex items-center justify-between">
          
          {/* Logo / Title */}
          <button
            onClick={() => onScrollToSection("hero")}
            className="flex items-center gap-2 text-white hover:opacity-90 transition-opacity cursor-none"
          >
            <Cpu className="text-cyan-400" size={18} />
            <span className="font-mono text-sm font-bold tracking-wider">RAZA_SPACE</span>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-8">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onScrollToSection(item.id)}
                className={`text-xs font-mono tracking-widest uppercase transition-colors relative cursor-none py-1 ${
                  activeSection === item.id
                    ? "text-cyan-400"
                    : "text-slate-400 hover:text-slate-100"
                }`}
              >
                {item.label}
                {activeSection === item.id && (
                  <motion.span
                    layoutId="activeIndicator"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400"
                    transition={{ type: "spring", stiffness: 350, damping: 30 }}
                  />
                )}
              </button>
            ))}
          </nav>

          {/* Action CTA link (LinkedIn) */}
          <div className="hidden md:flex items-center gap-4">
            <a
              href="https://www.linkedin.com/in/ashif-raza-2b735b2a3"
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded bg-slate-900 border border-slate-800 text-slate-300 font-mono text-[10px] tracking-wider font-semibold flex items-center gap-1 hover:bg-slate-850 hover:border-cyan-500/20 hover:text-cyan-400 transition-all cursor-none"
            >
              LINKEDIN <ArrowUpRight size={12} />
            </a>
          </div>

          {/* Mobile Menu trigger */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 rounded bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            {isOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden border-t border-slate-900 bg-slate-950 overflow-hidden"
            >
              <div className="px-4 py-6 space-y-4 flex flex-col">
                {menuItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setIsOpen(false);
                      onScrollToSection(item.id);
                    }}
                    className={`text-left text-sm font-mono tracking-widest uppercase py-2 border-b border-slate-900/40 ${
                      activeSection === item.id ? "text-cyan-400" : "text-slate-400"
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
                <a
                  href="https://www.linkedin.com/in/ashif-raza-2b735b2a3"
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3.5 rounded-lg bg-slate-900 border border-slate-850 text-center font-mono text-xs tracking-wider text-cyan-400 font-semibold block"
                >
                  LINKEDIN DIRECT
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </>
  );
}
