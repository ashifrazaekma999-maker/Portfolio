import { motion } from "motion/react";
import * as Icons from "lucide-react";

const skillCategories = [
  {
    category: "Programming Languages",
    skills: [
      { name: "Python", level: 95, icon: "Code" },
      { name: "C++", level: 80, icon: "Terminal" },
      { name: "JavaScript", level: 85, icon: "Cpu" },
      { name: "HTML", level: 90, icon: "Layout" },
      { name: "CSS", level: 85, icon: "Sparkles" }
    ]
  },
  {
    category: "Data Science & ML",
    skills: [
      { name: "Machine Learning", level: 90, icon: "Brain" },
      { name: "Data Analysis", level: 92, icon: "TrendingUp" },
      { name: "Pandas & NumPy", level: 95, icon: "Database" },
      { name: "Scikit-Learn", level: 88, icon: "Workflow" },
      { name: "TensorFlow", level: 75, icon: "Activity" },
      { name: "Matplotlib & Seaborn", level: 90, icon: "BarChart3" },
      { name: "Power BI & Excel", level: 85, icon: "Eye" }
    ]
  },
  {
    category: "Web & Cloud Platforms",
    skills: [
      { name: "Node.js", level: 80, icon: "Server" },
      { name: "React.js", level: 85, icon: "Layers" },
      { name: "Streamlit", level: 92, icon: "Tv" },
      { name: "Gradio", level: 88, icon: "Globe" },
      { name: "Firebase", level: 85, icon: "Flame" },
      { name: "MySQL & SQLite", level: 82, icon: "Database" }
    ]
  },
  {
    category: "Tools & Workflows",
    skills: [
      { name: "GitHub & Git", level: 90, icon: "Github" },
      { name: "VS Code", level: 95, icon: "FileCode" },
      { name: "Jupyter Notebook", level: 95, icon: "BookOpen" },
      { name: "Google Colab", level: 90, icon: "Cloud" }
    ]
  }
];

export default function Skills() {
  const renderIcon = (iconName: string) => {
    // Dynamically retrieve the Lucide icon, fallback to Terminal if not found
    const IconComponent = (Icons as any)[iconName] || Icons.Terminal;
    return <IconComponent size={18} className="text-cyan-400" />;
  };

  return (
    <section id="skills" className="py-24 relative px-4 max-w-7xl mx-auto">
      <div className="space-y-16">
        {/* Header */}
        <div className="text-center space-y-4">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-mono text-xs text-cyan-400 tracking-widest uppercase"
          >
            02 . TECHNICAL COMPETENCIES
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-5xl font-sans font-bold tracking-tight text-white"
          >
            My Skill Matrix
          </motion.h2>
          <div className="w-12 h-1 bg-cyan-500 mx-auto rounded" />
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {skillCategories.map((category, catIdx) => (
            <motion.div
              key={catIdx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: catIdx * 0.1, duration: 0.5 }}
              className="p-6 rounded-2xl bg-slate-900/40 border border-slate-900 hover:border-cyan-500/20 transition-all backdrop-blur-md shadow-xl flex flex-col space-y-6 group"
            >
              {/* Category Title */}
              <h3 className="text-base font-bold font-mono tracking-wider text-slate-200 uppercase pb-2 border-b border-slate-800 flex items-center justify-between">
                <span>{category.category}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-500" />
              </h3>

              {/* Skills list inside category */}
              <div className="space-y-5 flex-1">
                {category.skills.map((skill, skIdx) => (
                  <div key={skIdx} className="space-y-2">
                    {/* Skill label */}
                    <div className="flex items-center justify-between text-xs font-mono font-medium">
                      <div className="flex items-center gap-2 text-slate-300">
                        <span className="p-1 rounded bg-slate-950 border border-slate-800">
                          {renderIcon(skill.icon)}
                        </span>
                        <span>{skill.name}</span>
                      </div>
                      <span className="text-cyan-400">{skill.level}%</span>
                    </div>

                    {/* Skill progress bar */}
                    <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-900">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        viewport={{ once: true }}
                        transition={{ delay: skIdx * 0.05 + 0.2, duration: 0.8, ease: "easeOut" }}
                        className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
