import { motion } from "motion/react";
import { GraduationCap, Award, Target, Rocket, Milestone } from "lucide-react";

export default function About() {
  const stats = [
    { label: "B.Tech CGPA", value: "7.18", suffix: "/10", desc: "AI & Data Science" },
    { label: "Core Projects", value: "4", suffix: "+", desc: "IoT & Full-Stack AI" },
    { label: "Publications", value: "1", suffix: "", desc: "International IJEASM Journal" },
    { label: "Certifications", value: "3", suffix: "", desc: "IBM, Deloitte, Cisco" },
  ];

  const education = [
    {
      degree: "B.Tech – Artificial Intelligence & Data Science",
      inst: "Prestige Institute of Engineering Management & Research (PIEMR)",
      period: "2023 – 2027",
      grade: "CGPA: 7.18 / 10.00",
      desc: "Affiliated with RGPV, Bhopal. Rigorous curriculum spanning Machine Learning theory, deep neural structures, cloud deployment pipelines, databases, and structural data science mechanics.",
    },
    {
      degree: "12th Standard - Science (BSEB)",
      inst: "Rajendra College Chapra",
      period: "2021 – 2023",
      grade: "First Division",
      desc: "Comprehensive foundation in Physics, Chemistry, and Advanced Mathematics.",
    },
    {
      degree: "10th Standard (BSEB)",
      inst: "A N S High School Ekma",
      period: "2019 – 2021",
      grade: "First Division",
      desc: "Top academic standing with foundational problem-solving disciplines.",
    },
  ];

  return (
    <section id="about" className="py-24 relative px-4 max-w-7xl mx-auto">
      <div className="space-y-16">
        {/* Header */}
        <div className="text-center space-y-4">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-mono text-xs text-cyan-400 tracking-widest uppercase"
          >
            01 . BACKGROUND & VISION
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-5xl font-sans font-bold tracking-tight text-white"
          >
            Engineering Intelligence
          </motion.h2>
          <div className="w-12 h-1 bg-cyan-500 mx-auto rounded" />
        </div>

        {/* Narrative & Statistics Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Narrative */}
          <div className="lg:col-span-7 space-y-6">
            <h3 className="text-xl md:text-2xl font-semibold text-slate-200 flex items-center gap-2">
              <Rocket size={22} className="text-cyan-400" />
              Bridging Physical Insights with Deep Learning
            </h3>
            <p className="text-slate-400 text-sm md:text-base leading-relaxed">
              As an AI & Data Science Engineer, I specialize in engineering systems that convert raw physical signals into reliable predictive insight. My expertise lies in designing robust Python pipelines, training custom Machine Learning architectures (classification, regression, NLP similarity), and implementing fluid full-stack interfaces with Firebase and React.
            </p>
            <p className="text-slate-400 text-sm md:text-base leading-relaxed">
              I am driven by practical problems—from developing travel analytics systems like <span className="text-cyan-400">Trip Dhara</span> (published in an international journal) to constructing IoT-based vibration monitoring loops for mechanical motors (<span className="text-cyan-400">Predictive Maintenance</span>). I seek environments where I can apply rigorous computational analysis to secure, optimize, and streamline production.
            </p>

            {/* Career Goals */}
            <div className="p-5 rounded-xl bg-slate-900/40 border border-slate-800/80 backdrop-blur-md space-y-3">
              <h4 className="font-semibold text-slate-200 flex items-center gap-2 text-sm font-mono tracking-wider">
                <Target size={16} className="text-cyan-400" />
                PRIMARY CAREER TARGETS
              </h4>
              <p className="text-xs md:text-sm text-slate-400 leading-relaxed">
                Aiming to pioneer predictive engineering solutions in complex industrial systems. Intended goals include developing automated deep neural classifiers for physical telemetry, structuring high-performance pipeline caching, and shipping scalable, secure AI interfaces that optimize resource allocation.
              </p>
            </div>
          </div>

          {/* Avatar and Stats */}
          <div className="lg:col-span-5 space-y-6">
            {/* Visual Profile Mockup */}
            <div className="relative group overflow-hidden rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 p-6 border border-slate-800/80 shadow-2xl flex flex-col items-center text-center">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              {/* Profile Glow Ring */}
              <div className="relative w-32 h-32 rounded-full p-1 bg-gradient-to-tr from-cyan-500 to-blue-500 shadow-[0_0_20px_rgba(6,182,212,0.2)] mb-4">
                <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center overflow-hidden">
                  <div className="text-3xl font-sans font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">
                    AR
                  </div>
                </div>
              </div>

              <h4 className="text-lg font-bold text-slate-200">Ashif Raza</h4>
              <p className="text-xs text-cyan-400 font-mono tracking-wider">B.Tech (AI & Data Science)</p>
              <p className="text-xs text-slate-500 mt-2">Ph: +91 9798400721</p>
              <p className="text-xs text-slate-500">ashifrazaekma999@gmail.com</p>
            </div>

            {/* Stats list */}
            <div className="grid grid-cols-2 gap-4">
              {stats.map((s, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-slate-900/25 border border-slate-900 hover:border-cyan-500/30 transition-all text-center backdrop-blur-sm shadow-md"
                >
                  <p className="text-xs font-mono text-slate-500 uppercase">{s.label}</p>
                  <div className="text-2xl md:text-3xl font-bold font-mono text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400 my-1">
                    {s.value}
                    <span className="text-sm font-sans font-normal text-slate-400">{s.suffix}</span>
                  </div>
                  <p className="text-[10px] text-slate-400 leading-tight">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Education Timeline */}
        <div className="space-y-8 pt-8">
          <h3 className="text-xl md:text-2xl font-semibold text-slate-200 flex items-center gap-2">
            <GraduationCap size={24} className="text-cyan-400" />
            Academic Career
          </h3>

          <div className="relative border-l border-slate-800 ml-3 space-y-12">
            {education.map((edu, idx) => (
              <div key={idx} className="relative pl-8">
                {/* Timeline node */}
                <span className="absolute -left-3 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-slate-950 border-2 border-cyan-500/80 shadow-[0_0_8px_rgba(6,182,212,0.4)]">
                  <Milestone size={10} className="text-cyan-400" />
                </span>

                {/* Glass card content */}
                <div className="p-6 rounded-xl bg-slate-900/20 border border-slate-900/60 hover:border-slate-800 transition-all backdrop-blur-md space-y-2 max-w-4xl">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-1">
                    <h4 className="text-base md:text-lg font-bold text-slate-200">{edu.degree}</h4>
                    <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950/40 px-2.5 py-1 rounded border border-cyan-500/20 w-fit">
                      {edu.period}
                    </span>
                  </div>
                  <p className="text-xs font-mono font-semibold text-slate-400">{edu.inst}</p>
                  <p className="text-xs font-bold text-slate-300 font-mono inline-block bg-slate-900/80 px-2 py-0.5 rounded">
                    {edu.grade}
                  </p>
                  <p className="text-xs md:text-sm text-slate-400 leading-relaxed pt-1">{edu.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
