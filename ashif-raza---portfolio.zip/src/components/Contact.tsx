import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mail, Phone, MapPin, Send, MessageSquare, Linkedin, Github, CheckCircle, Navigation } from "lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<"idle" | "success" | "error">("idle");

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      alert("Please provide at least a name, email, and description message.");
      return;
    }

    setIsSubmitting(true);
    setSubmitStatus("idle");

    try {
      // Simulate API integration (EmailJS hook mockup)
      await new Promise((resolve) => setTimeout(resolve, 1500));
      setIsSubmitting(false);
      setSubmitStatus("success");
      setFormData({ name: "", email: "", phone: "", message: "" });
      
      // Reset success notification after a delay
      setTimeout(() => setSubmitStatus("idle"), 4000);
    } catch (err) {
      setIsSubmitting(false);
      setSubmitStatus("error");
    }
  };

  return (
    <section id="contact" className="py-24 relative px-4 max-w-7xl mx-auto">
      <div className="space-y-16">
        {/* Header */}
        <div className="text-center space-y-4">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-mono text-xs text-cyan-400 tracking-widest uppercase"
          >
            06 . COMMUNICATIONS & CHANNELS
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-5xl font-sans font-bold tracking-tight text-white"
          >
            Let's Collaborate
          </motion.h2>
          <div className="w-12 h-1 bg-cyan-500 mx-auto rounded" />
        </div>

        {/* Form and Map Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Contacts Details & Form */}
          <div className="lg:col-span-7 space-y-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Email Card */}
              <a
                href="mailto:ashifrazaekma999@gmail.com"
                className="p-5 rounded-xl bg-slate-900/30 border border-slate-900 hover:border-cyan-500/30 transition-all backdrop-blur-md flex items-center gap-4 group"
              >
                <span className="p-3 rounded bg-cyan-950/40 border border-cyan-500/20 text-cyan-400 group-hover:bg-cyan-500/10 transition-colors">
                  <Mail size={18} />
                </span>
                <div>
                  <p className="text-[10px] font-mono text-slate-500">EMAIL</p>
                  <p className="text-xs md:text-sm font-bold text-slate-200 truncate max-w-[180px]">
                    ashifrazaekma999@gmail.com
                  </p>
                </div>
              </a>

              {/* Phone / Whatsapp */}
              <a
                href="https://wa.me/919798400721"
                target="_blank"
                rel="noreferrer"
                className="p-5 rounded-xl bg-slate-900/30 border border-slate-900 hover:border-cyan-500/30 transition-all backdrop-blur-md flex items-center gap-4 group"
              >
                <span className="p-3 rounded bg-cyan-950/40 border border-cyan-500/20 text-cyan-400 group-hover:bg-cyan-500/10 transition-colors">
                  <MessageSquare size={18} />
                </span>
                <div>
                  <p className="text-[10px] font-mono text-slate-500">WHATSAPP & VOICE</p>
                  <p className="text-xs md:text-sm font-bold text-slate-200">
                    +91 9798400721
                  </p>
                </div>
              </a>
            </div>

            {/* Glass Contact Form */}
            <form
              onSubmit={handleFormSubmit}
              className="p-6 md:p-8 rounded-2xl bg-slate-900/15 border border-slate-900/80 backdrop-blur-md space-y-5"
            >
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Send size={16} className="text-cyan-400" /> Secure Message Router
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Name */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-500 uppercase">Your Name *</label>
                  <input
                    type="text"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Enter full name"
                    className="w-full px-4 py-3 text-xs text-slate-200 bg-slate-950 border border-slate-900 rounded-lg focus:outline-none focus:border-cyan-500/40 transition-colors font-sans"
                  />
                </div>

                {/* Email */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono text-slate-500 uppercase">Your Email *</label>
                  <input
                    type="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="Enter email address"
                    className="w-full px-4 py-3 text-xs text-slate-200 bg-slate-950 border border-slate-900 rounded-lg focus:outline-none focus:border-cyan-500/40 transition-colors font-sans"
                  />
                </div>
              </div>

              {/* Phone */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-500 uppercase">Phone Number (Optional)</label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  placeholder="Enter contact number"
                  className="w-full px-4 py-3 text-xs text-slate-200 bg-slate-950 border border-slate-900 rounded-lg focus:outline-none focus:border-cyan-500/40 transition-colors font-sans"
                />
              </div>

              {/* Message */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-500 uppercase">Message Description *</label>
                <textarea
                  name="message"
                  required
                  rows={4}
                  value={formData.message}
                  onChange={handleInputChange}
                  placeholder="Draft your proposal or inquiry here..."
                  className="w-full px-4 py-3 text-xs text-slate-200 bg-slate-950 border border-slate-900 rounded-lg focus:outline-none focus:border-cyan-500/40 transition-colors font-sans resize-none"
                />
              </div>

              {/* Submit button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 hover:opacity-95 disabled:opacity-50 transition-all cursor-none"
              >
                {isSubmitting ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    routing packet...
                  </>
                ) : (
                  <>
                    <Send size={12} /> route message
                  </>
                )}
              </button>

              {/* Status notifications */}
              <AnimatePresence>
                {submitStatus === "success" && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="p-4 rounded bg-emerald-950/20 border border-emerald-500/20 text-emerald-400 text-xs font-sans flex items-center gap-2"
                  >
                    <CheckCircle size={14} />
                    Message routed successfully! Ashif will connect via email shortly.
                  </motion.div>
                )}
              </AnimatePresence>
            </form>
          </div>

          {/* Interactive Location Map Panel */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 rounded-2xl bg-slate-900/10 border border-slate-900/80 backdrop-blur-md flex flex-col justify-between h-full space-y-6 overflow-hidden relative">
              {/* Map coordinate metadata */}
              <div className="space-y-1">
                <span className="text-[9px] font-mono text-cyan-400 flex items-center gap-1">
                  <Navigation size={10} className="animate-pulse" /> CURRENT CO-ORDINATES
                </span>
                <h4 className="text-sm font-bold text-slate-200">Bhopal / Indore, MP, India</h4>
                <p className="text-[10px] font-mono text-slate-500">Lat: 22.7196° N | Lon: 75.8577° E</p>
              </div>

              {/* Vector Digital Globe Maps Placeholder */}
              <div className="aspect-square rounded-xl bg-slate-950 border border-slate-900 relative flex items-center justify-center overflow-hidden group">
                {/* Circuit Grid matrix */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:16px_16px] [mask-image:radial-gradient(ellipse_60%_60%_at_50%_50%,#000_70%,transparent_100%)] opacity-60" />

                {/* Glowing target rings representing current location */}
                <span className="absolute w-24 h-24 rounded-full border border-cyan-500/10 animate-ping" style={{ animationDuration: "3s" }} />
                <span className="absolute w-12 h-12 rounded-full border border-cyan-500/20 animate-ping" style={{ animationDuration: "2s" }} />
                
                {/* Concentric rings */}
                <div className="w-32 h-32 rounded-full border border-slate-800/40 flex items-center justify-center relative">
                  <div className="w-16 h-16 rounded-full border border-slate-800/80 flex items-center justify-center">
                    <span className="w-4 h-4 rounded-full bg-cyan-500 animate-pulse shadow-[0_0_15px_rgba(6,182,212,0.8)] flex items-center justify-center">
                      <MapPin size={10} className="text-slate-950" />
                    </span>
                  </div>
                </div>

                {/* Cyber Matrix visualizer overlay */}
                <div className="absolute bottom-4 left-4 right-4 bg-slate-900/80 border border-slate-800/60 p-3 rounded-lg backdrop-blur-md flex items-center justify-between text-[10px] font-mono text-slate-400">
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
                    PRESTIGE INSTITUTE PIEMR
                  </span>
                  <span className="text-cyan-400">BHOPAL-INDORE HUB</span>
                </div>
              </div>

              {/* Social Channels buttons footer */}
              <div className="flex items-center gap-3 justify-center pt-2 text-slate-500 border-t border-slate-900">
                <a
                  href="https://www.linkedin.com/in/ashif-raza-2b735b2a3"
                  target="_blank"
                  rel="noreferrer"
                  className="p-2.5 rounded-lg bg-slate-950 hover:bg-slate-900 border border-slate-900 text-slate-400 hover:text-cyan-400 transition-colors"
                  title="LinkedIn Profile"
                >
                  <Linkedin size={16} />
                </a>
                <a
                  href="https://github.com/ashifrazaekma"
                  target="_blank"
                  rel="noreferrer"
                  className="p-2.5 rounded-lg bg-slate-950 hover:bg-slate-900 border border-slate-900 text-slate-400 hover:text-cyan-400 transition-colors"
                  title="GitHub Profile"
                >
                  <Github size={16} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
