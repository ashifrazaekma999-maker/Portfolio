import { motion } from "motion/react";
import * as Icons from "lucide-react";

const servicesList = [
  {
    title: "Machine Learning",
    description: "Custom model training, tuning, feature engineering, and deployment (Classification, Regression, Clustering, and Time Series Forecasting).",
    icon: "Brain"
  },
  {
    title: "Python Development",
    description: "High-quality, modular Python engineering, automation scripting, data processing pipelines, and microservices.",
    icon: "Terminal"
  },
  {
    title: "Data Analysis",
    description: "Exploratory data analysis, comprehensive statistical profiling, interactive Power BI / Streamlit dashboard visualizations, and custom report building.",
    icon: "BarChart3"
  },
  {
    title: "AI Applications",
    description: "Full-stack development of Intelligent chat agents, semantic search tools, NLP pipelines, and PDF analysis engines.",
    icon: "Cpu"
  },
  {
    title: "Web Development",
    description: "Modern full-stack single-page or server-side reactive applications utilizing React.js, Express, Node.js, and Cloud services.",
    icon: "Globe"
  },
  {
    title: "AI Consulting",
    description: "Architectural advice on model selection, API integrations (Gemini, OpenAI), cloud data pipelines, and cost optimization.",
    icon: "Eye"
  }
];

export default function Services() {
  const renderIcon = (iconName: string) => {
    const IconComponent = (Icons as any)[iconName] || Icons.Cpu;
    return <IconComponent size={22} className="text-cyan-400" />;
  };

  return (
    <section id="services" className="py-24 relative px-4 max-w-7xl mx-auto border-t border-slate-900/60">
      <div className="space-y-16">
        {/* Header */}
        <div className="text-center space-y-4">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-mono text-xs text-cyan-400 tracking-widest uppercase"
          >
            07 . SERVICES & SOLUTIONS
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-5xl font-sans font-bold tracking-tight text-white"
          >
            What I Deliver
          </motion.h2>
          <div className="w-12 h-1 bg-cyan-500 mx-auto rounded" />
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {servicesList.map((service, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.05, duration: 0.5 }}
              whileHover={{ y: -6 }}
              className="p-6 rounded-2xl bg-slate-900/10 border border-slate-900 hover:border-cyan-500/25 transition-all duration-300 backdrop-blur-md relative overflow-hidden group"
            >
              {/* Soft corner glowing accent */}
              <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="space-y-4 relative z-10">
                {/* Icon wrapper */}
                <span className="inline-flex p-3 rounded-xl bg-slate-950 border border-slate-900 group-hover:border-cyan-500/20 transition-colors">
                  {renderIcon(service.icon)}
                </span>

                {/* Title */}
                <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="text-xs md:text-sm text-slate-400 leading-relaxed">
                  {service.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
