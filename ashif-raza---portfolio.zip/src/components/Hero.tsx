import { motion } from "motion/react";
import React, { useEffect, useState } from "react";
import { ArrowRight, MessageSquare, Briefcase, FileText, Github, Linkedin, Mail, Phone } from "lucide-react";

interface HeroProps {
  onScrollToSection: (id: string) => void;
  onOpenChat: () => void;
}

export default function Hero({ onScrollToSection, onOpenChat }: HeroProps) {
  const roles = [
    "Machine Learning Engineer",
    "Python Developer",
    "Data Scientist",
    "Full Stack AI Developer"
  ];
  const [roleIndex, setRoleIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    const currentFullRole = roles[roleIndex];

    const type = () => {
      if (!isDeleting) {
        setDisplayedText(currentFullRole.substring(0, displayedText.length + 1));
        if (displayedText === currentFullRole) {
          timer = setTimeout(() => setIsDeleting(true), 2000); // Wait before deleting
        } else {
          timer = setTimeout(type, 100);
        }
      } else {
        setDisplayedText(currentFullRole.substring(0, displayedText.length - 1));
        if (displayedText === "") {
          setIsDeleting(false);
          setRoleIndex((prev) => (prev + 1) % roles.length);
          timer = setTimeout(type, 500); // Pause before next role
        } else {
          timer = setTimeout(type, 50);
        }
      }
    };

    timer = setTimeout(type, 100);
    return () => clearTimeout(timer);
  }, [displayedText, isDeleting, roleIndex]);

  // Magnetic button hover simulation
  const [magneticCoords, setMagneticCoords] = useState({ x: 0, y: 0 });
  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    setMagneticCoords({ x: x * 0.35, y: y * 0.35 });
  };
  const handleMouseLeave = () => {
    setMagneticCoords({ x: 0, y: 0 });
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col items-center justify-center text-center px-4 overflow-hidden pt-20"
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="max-w-4xl z-10 space-y-6"
      >
        {/* Top Floating Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-950/40 border border-cyan-500/30 text-cyan-400 text-xs font-mono tracking-wider shadow-[0_0_15px_rgba(6,182,212,0.15)] backdrop-blur-md"
        >
          <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
          AVAILABLE FOR INTERNSHIPS & AI OPPORTUNITIES
        </motion.div>

        {/* Small greeting */}
        <h3 className="font-mono text-sm tracking-widest text-slate-400 uppercase">
          Welcome to the digital neural space of
        </h3>

        {/* Name */}
        <h1 className="text-5xl md:text-8xl font-sans font-extrabold tracking-tighter text-transparent bg-clip-text bg-gradient-to-b from-white via-slate-100 to-slate-400 select-none">
          ASHIF RAZA
        </h1>

        {/* Typist */}
        <div className="h-12 flex items-center justify-center">
          <p className="text-xl md:text-3xl font-mono font-medium text-cyan-400 drop-shadow-[0_0_8px_rgba(6,182,212,0.3)]">
            {displayedText}
            <span className="inline-block w-1.5 h-6 ml-1 bg-cyan-400 animate-pulse" />
          </p>
        </div>

        {/* Tagline */}
        <p className="text-sm md:text-lg text-slate-400 max-w-2xl mx-auto font-sans leading-relaxed">
          B.Tech student in <span className="text-slate-200">Artificial Intelligence & Data Science</span>.
          Weaving industrial physics and deep learning schemas together to construct robust, predictive, and intelligent system architectures.
        </p>

        {/* CTA buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-6">
          <motion.button
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            animate={{ x: magneticCoords.x, y: magneticCoords.y }}
            transition={{ type: "spring", stiffness: 150, damping: 15 }}
            onClick={() => onScrollToSection("projects")}
            className="w-full sm:w-auto px-6 py-3.5 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-medium text-sm flex items-center justify-center gap-2 hover:shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all cursor-none"
          >
            Explore Projects
            <ArrowRight size={16} />
          </motion.button>

          <button
            onClick={() => onScrollToSection("documents")}
            className="w-full sm:w-auto px-6 py-3.5 rounded-lg bg-slate-900/60 border border-slate-800 text-slate-300 font-medium text-sm flex items-center justify-center gap-2 hover:bg-slate-850 hover:border-slate-750 transition-all backdrop-blur-md"
          >
            <FileText size={16} className="text-cyan-400" />
            Document Library
          </button>

          <button
            onClick={onOpenChat}
            className="w-full sm:w-auto px-6 py-3.5 rounded-lg bg-cyan-950/20 border border-cyan-500/20 text-cyan-400 font-medium text-sm flex items-center justify-center gap-2 hover:bg-cyan-950/40 hover:border-cyan-500/40 transition-all backdrop-blur-md"
          >
            <MessageSquare size={16} />
            Ask RazaBot AI
          </button>
        </div>

        {/* Social connections */}
        <div className="flex items-center justify-center gap-5 pt-8 text-slate-500">
          <a
            href="https://github.com/ashifrazaekma"
            target="_blank"
            rel="noreferrer"
            className="hover:text-cyan-400 transition-colors"
            title="GitHub"
          >
            <Github size={20} />
          </a>
          <a
            href="https://www.linkedin.com/in/ashif-raza-2b735b2a3"
            target="_blank"
            rel="noreferrer"
            className="hover:text-cyan-400 transition-colors"
            title="LinkedIn"
          >
            <Linkedin size={20} />
          </a>
          <a
            href="mailto:ashifrazaekma999@gmail.com"
            className="hover:text-cyan-400 transition-colors"
            title="Email"
          >
            <Mail size={20} />
          </a>
          <a
            href="tel:+919798400721"
            className="hover:text-cyan-400 transition-colors"
            title="Phone"
          >
            <Phone size={20} />
          </a>
        </div>
      </motion.div>

      {/* Background radial soft light */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyan-500/5 rounded-full blur-[100px] pointer-events-none -z-10" />
      <div className="absolute top-1/3 left-1/4 w-[300px] h-[300px] bg-blue-500/5 rounded-full blur-[80px] pointer-events-none -z-10 animate-pulse" />
    </section>
  );
}
