import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Cpu, Terminal } from "lucide-react";

// Component imports
import Header from "./components/Header";
import Hero from "./components/Hero";
import About from "./components/About";
import Skills from "./components/Skills";
import Projects from "./components/Projects";
import Services from "./components/Services";
import Documents from "./components/Documents";
import Timeline from "./components/Timeline";
import Testimonials from "./components/Testimonials";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import Chatbot from "./components/Chatbot";
import ThreeBackground from "./components/ThreeBackground";
import CustomCursor from "./components/CustomCursor";

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [loadingPercent, setLoadingPercent] = useState(0);
  const [activeSection, setActiveSection] = useState("hero");
  const [isChatOpen, setIsChatOpen] = useState(false);
  const chatRef = useRef<any>(null);

  // 1. Loader simulation loop
  useEffect(() => {
    if (loadingPercent < 100) {
      const interval = setInterval(() => {
        setLoadingPercent((prev) => {
          const increment = Math.floor(Math.random() * 8) + 4;
          const next = prev + increment;
          if (next >= 100) {
            clearInterval(interval);
            setTimeout(() => setIsLoading(false), 600); // Wait for transition
            return 100;
          }
          return next;
        });
      }, 80);
      return () => clearInterval(interval);
    }
  }, [loadingPercent]);

  // 2. Navigation smooth scrolling helper
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  // 3. Section visibility tracker (Intersection Observer)
  useEffect(() => {
    if (isLoading) return;

    const sections = ["hero", "about", "skills", "projects", "documents", "timeline", "contact"];
    const observers: IntersectionObserver[] = [];

    sections.forEach((sectionId) => {
      const el = document.getElementById(sectionId);
      if (el) {
        const observer = new IntersectionObserver(
          ([entry]) => {
            if (entry.isIntersecting) {
              setActiveSection(sectionId);
            }
          },
          { threshold: 0.25, rootMargin: "-10% 0px -40% 0px" }
        );
        observer.observe(el);
        observers.push(observer);
      }
    });

    return () => {
      observers.forEach((o) => o.disconnect());
    };
  }, [isLoading]);

  // Trigger floating chatbot focus
  const handleOpenChat = () => {
    // We can simulate chatbot opening by finding its trigger element or using State
    // Simply updating a global listener or triggering a click on the floating button
    const chatBtn = document.querySelector("button[class*='w-14 h-14']") as HTMLElement;
    if (chatBtn) {
      chatBtn.click();
    }
  };

  return (
    <>
      {/* 1. Loader Layer */}
      <AnimatePresence mode="wait">
        {isLoading && (
          <motion.div
            key="loader"
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="fixed inset-0 bg-slate-950 z-50 flex flex-col items-center justify-center p-4 select-none"
          >
            <div className="space-y-8 max-w-sm w-full text-center">
              {/* Spinner icon */}
              <div className="relative w-20 h-20 mx-auto flex items-center justify-center">
                <span className="absolute inset-0 rounded-full border-4 border-slate-900 border-t-cyan-500 animate-spin" />
                <Cpu className="text-cyan-400 animate-pulse" size={24} />
              </div>

              {/* Status block */}
              <div className="space-y-2">
                <p className="font-mono text-[10px] tracking-widest text-cyan-500 uppercase flex items-center justify-center gap-1">
                  <Terminal size={10} /> INITIALIZING NEURAL MESH...
                </p>
                <div className="text-2xl font-mono font-bold text-slate-100">
                  {loadingPercent}%
                </div>
              </div>

              {/* Progress bar */}
              <div className="h-1 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-900/40">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-75"
                  style={{ width: `${loadingPercent}%` }}
                />
              </div>

              <p className="text-[10px] text-slate-500 font-mono italic">
                Ashif Raza AI Portfolio Space v3.1.2
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. Main Content Space */}
      {!isLoading && (
        <div className="text-slate-100 antialiased font-sans selection:bg-cyan-500/20 selection:text-cyan-300 min-h-screen relative overflow-x-hidden">
          {/* Custom interactive cursor */}
          <CustomCursor />

          {/* Canvas Digital Background */}
          <ThreeBackground />

          {/* Sticky glass Header navigation */}
          <Header onScrollToSection={scrollToSection} activeSection={activeSection} />

          {/* Page Sections */}
          <main className="relative">
            <Hero onScrollToSection={scrollToSection} onOpenChat={handleOpenChat} />
            
            {/* Fade divider */}
            <div className="h-24 w-full bg-gradient-to-b from-transparent to-slate-950/20 pointer-events-none" />
            
            <About />
            <Skills />
            <Projects />
            <Services />
            <Documents />
            <Timeline />
            <Testimonials />
            <Contact />
          </main>

          {/* Footer details */}
          <Footer onScrollToSection={scrollToSection} />

          {/* Interactive Floating Chatbot representative */}
          <Chatbot />
        </div>
      )}
    </>
  );
}
